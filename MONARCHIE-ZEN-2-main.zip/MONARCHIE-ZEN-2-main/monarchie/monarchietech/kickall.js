import config from '../../config.cjs';

const kickAll = async (m, gss) => {
  try {
    const botNumber = await gss.decodeJid(gss.user.id);
    const prefix = config.PREFIX;
    const cmd = m.body.startsWith(prefix) ? m.body.slice(prefix.length).split(' ')[0].toLowerCase() : '';

    if (cmd !== 'kickall') return;
    if (!m.isGroup) return m.reply('🚫 *Commande disponible uniquement dans les groupes.*');

    const groupMetadata = await gss.groupMetadata(m.from);
    const participants = groupMetadata.participants;
    const botAdmin = participants.find(p => p.id === botNumber)?.admin;
    const senderAdmin = participants.find(p => p.id === m.sender)?.admin;

    if (!botAdmin) return m.reply('❌ *MONARCHIE-ZEN doit être administrateur pour exécuter cet ordre.*');
    if (!senderAdmin) return m.reply('🛑 *Tu n’as pas l’autorité requise pour invoquer cette purge.*');

    // Exclure les admins du kick
    const targets = participants
      .filter(p => !p.admin && p.id !== botNumber)
      .map(p => p.id);

    if (targets.length === 0) {
      return m.reply('⚠️ *Aucun membre à expulser (hors admins).*');
    }

    await gss.groupParticipantsUpdate(m.from, targets, 'remove')
      .then(() => {
        const names = targets.map(user => `@${user.split("@")[0]}`).join(', ');

        m.reply(
`⚔️ *EXÉCUTION ROYALE ACTIVÉE...*

📤 *Cibles* : ${names}
🏰 *Groupe* : ${groupMetadata.subject}

☠️ *Statut* : Éliminés
📛 *Système* : OPÉRATION DE NETTOYAGE COMPLÈTE.
👑 *Autorité* : dev monarchie
📞 *Bot* : +243905061118
🔗 *Chaîne Officielle* : https://whatsapp.com/channel/0029VbAYjn5KgsNpws3P633r
`
        );

        gss.sendMessage(m.from, {
          text: `🔥 *Nettoyage accompli avec succès...*\n\n🧹 *Membres expulsés :* ${names}`,
          mentions: targets
        });
      })
      .catch(() => m.reply('❌ *Échec de l’exécution de la purge.*'));
  } catch (error) {
    console.error('Erreur dans kickall :', error);
    m.reply('💥 *Erreur système lors de l’exécution de la purge.*');
  }
};

export default kickAll;