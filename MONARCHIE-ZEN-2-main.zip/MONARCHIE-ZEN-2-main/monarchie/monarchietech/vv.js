import pkg from '@whiskeysockets/baileys';
const { downloadMediaMessage } = pkg;
import config from '../../config.cjs';

const OwnerCmd = async (m, Matrix) => {
  const botNumber = Matrix.user.id.split(':')[0] + '@s.whatsapp.net';
  const ownerNumber = config.OWNER_NUMBER + '@s.whatsapp.net';
  const prefix = config.PREFIX;
  const cmd = m.body.startsWith(prefix) ? m.body.slice(prefix.length).split(' ')[0].toLowerCase() : '';

  const isOwner = m.sender === ownerNumber;
  const isBot = m.sender === botNumber;

  if (!['vv', 'vv2', 'vv3'].includes(cmd)) return;
  if (!m.quoted) return m.reply('*Reply to a View Once message!*');

  const viewOnce = m.quoted.message?.viewOnceMessageV2?.message || m.quoted.message?.viewOnceMessage?.message;
  if (!viewOnce) return m.reply('*This is not a View Once message!*');

  if (!isOwner && !isBot) {
    return m.reply('*Only the owner or bot can use this command!*');
  }

  try {
    const messageType = Object.keys(viewOnce)[0];
    let buffer;

    if (messageType === 'audioMessage') {
      buffer = await downloadMediaMessage(m.quoted, 'buffer', {}, { type: 'audio' });
    } else {
      buffer = await downloadMediaMessage(m.quoted, 'buffer');
    }

    if (!buffer) return m.reply('*Failed to retrieve media!*');

    const mimetype = viewOnce.audioMessage?.mimetype || 'audio/ogg';
    const caption = `_📥 VIEW ONCE RECOVERED BY MONARCHIE-ZEN_`;

    let recipient = m.from;
    if (cmd === 'vv2') recipient = botNumber;
    if (cmd === 'vv3') recipient = ownerNumber;

    switch (messageType) {
      case 'imageMessage':
        await Matrix.sendMessage(recipient, { image: buffer, caption });
        break;
      case 'videoMessage':
        await Matrix.sendMessage(recipient, { video: buffer, caption, mimetype: 'video/mp4' });
        break;
      case 'audioMessage':
        await Matrix.sendMessage(recipient, { audio: buffer, mimetype, ptt: true });
        break;
      default:
        return m.reply('*Unsupported media type!*');
    }
  } catch (error) {
    console.error(error);
    await m.reply('*Failed to process View Once message!*');
  }
};

export default OwnerCmd;