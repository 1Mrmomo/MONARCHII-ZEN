import config from '../../config.cjs';

const gcEvent = async (m, Matrix) => {
  const prefix = config.PREFIX;
  const cmd = m.body.startsWith(prefix) ? m.body.slice(prefix.length).split(' ')[0].toLowerCase() : '';
  const text = m.body.slice(prefix.length + cmd.length).trim();

  if (cmd === 'welcome') {
    if (!m.isGroup) return m.reply("🚫 *Cette commande fonctionne uniquement dans un groupe.*");

    let responseMessage;

    if (text === 'on') {
      config.WELCOME = true;
      responseMessage = `╭──〔 👑 *PORTAIL D'INVOCATION ACTIVÉ* 〕──╮
│  
│  ✦ Les messages de *Bienvenue & Départ*  
│     ont été *activés* avec succès.  
│
│  ✦ Chaque nouvel arrivant sera accueilli  
│     dans le royaume du *Souverain des Ombres*. 🌑  
│  
│  ⚔️ *Préparez les invocations...*
╰────────────────────────────────╯`;
    } else if (text === 'off') {
      config.WELCOME = false;
      responseMessage = `╭──〔 🛑 *PORTAIL FERMÉ* 〕──╮
│  
│  ✦ Les messages de *Bienvenue & Départ*  
│     ont été *désactivés*.  
│
│  ✦ Aucun nouveau guerrier ne sera  
│     invoqué ou salué. ❌  
│  
│  ⚠️ *Silence dans l'ombre...*
╰────────────────────────────╯`;
    } else {
      responseMessage = `╭──〔 📘 *UTILISATION DE WELCOME* 〕──╮
│  
│  ✦ *Commande :* \`${prefix}welcome on\`  
│     ➥ Active les messages d'invocation
│  
│  ✦ *Commande :* \`${prefix}welcome off\`  
│     ➥ Désactive les messages d'invocation
│  
│  🕶️ *Style : Solo Leveling*
╰────────────────────────────────╯`;
    }

    try {
      await Matrix.sendMessage(m.from, { text: responseMessage }, { quoted: m });
    } catch (error) {
      console.error("Erreur :", error);
      await Matrix.sendMessage(m.from, { text: '❌ *Une erreur est survenue pendant le traitement.*' }, { quoted: m });
    }
  }
};

export default gcEvent;