import config from '../../config.cjs';

const leaveGroup = async (m, gss) => {
  try {
    const botNumber = await gss.decodeJid(gss.user.id);
    const isCreator = [botNumber, config.OWNER_NUMBER + '@s.whatsapp.net'].includes(m.sender);
    const prefix = config.PREFIX;

    const cmd = m.body.startsWith(prefix)
      ? m.body.slice(prefix.length).split(' ')[0].toLowerCase()
      : '';
    const validCommands = ['leave', 'exit', 'left'];
    
    if (!validCommands.includes(cmd)) return;
    if (!m.isGroup) return m.reply('🚫 *Commande disponible uniquement dans les groupes.*');
    if (!isCreator) return m.reply('⛔ *Seul l’architecte du système (dev monarchie) peut activer ce départ.*');

    // Message d’adieu stylisé
    await gss.sendMessage(m.from, {
      text: `
🌑 *MONARCHIE-ZEN* se retire...

🏰 *Groupe* : ${m.pushName || 'Inconnu'}
🔚 *Statut* : Royaume quitté
📞 *Bot* : +243905061118
🔗 *Chaîne* : https://whatsapp.com/channel/0029VbAYjn5KgsNpws3P633r

👑 *Dev* : dev monarchie
⚔️ *Système* : EXÉCUTION DE SORTIE TERMINÉE.
      `
    });

    await gss.groupLeave(m.from);
  } catch (error) {
    console.error('Erreur lors du leaveGroup :', error);
    m.reply('💥 *Erreur lors de l’exécution de la sortie.*');
  }
};

export default leaveGroup;