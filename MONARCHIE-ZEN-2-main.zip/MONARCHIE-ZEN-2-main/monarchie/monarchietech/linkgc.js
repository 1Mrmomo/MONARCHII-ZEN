import config from '../../config.cjs';

const linkgc = async (m, gss) => {
  try {
    const prefix = config.PREFIX;
    const cmd = m.body.startsWith(prefix)
      ? m.body.slice(prefix.length).split(' ')[0].toLowerCase()
      : '';

    const validCommands = ['linkgc', 'grouplink'];
    if (!validCommands.includes(cmd)) return;

    if (!m.isGroup) {
      return m.reply('🚫 *Cette commande ne fonctionne que dans un royaume (groupe).*');
    }

    const groupMetadata = await gss.groupMetadata(m.from);
    const botNumber = await gss.decodeJid(gss.user.id);
    const isBotAdmin = groupMetadata.participants.find(p => p.id === botNumber)?.admin;

    if (!isBotAdmin) {
      return m.reply('🛡️ *MONARCHIE-ZEN doit être administrateur pour générer le lien.*');
    }

    const inviteCode = await gss.groupInviteCode(m.from);

    await gss.sendMessage(m.from, {
      text: `
🌐 *PORTAIL DU ROYAUME OUVERT*

🏷️ *Nom du royaume* : ${groupMetadata.subject}
🔗 *Lien d’invocation* :
https://chat.whatsapp.com/${inviteCode}

👑 *MONARCHIE-ZEN* — Dev: dev monarchie
📞 *Bot* : +243905061118
📣 *Chaîne* : https://whatsapp.com/channel/0029VbAYjn5KgsNpws3P633r

⚔️ *N’ayez crainte. Le système veille.*
      `.trim(),
      detectLink: true
    });

  } catch (error) {
    console.error('Erreur lors de linkgc :', error);
    m.reply('💥 *Erreur lors de l’ouverture du portail du royaume.*');
  }
};

export default linkgc;