import sys
import os

ntfile = ['.module', 'lib']

def read_file(path):
    try:
        with open(path, 'r') as f:
            return f.read().strip()
    except Exception as e:
        print(f"[x] Erreur de lecture du fichier {path}: {e}")
        sys.exit()

ubuntu = read_file('.module/jalurU.ms')
termux = read_file('.module/jalurT.ms')
termlb = read_file('.module/ngentot.ms')
instal = read_file('.module/IN.ms')

def execute_module_files(prefix, interpreter):
    for letter in 'ABCDEFGH':
        file_path = f'.module/{letter}.ms'
        module = read_file(file_path)
        os.system(f"{interpreter} {prefix}{module}")

def show_banner():
    print("\n===================================")
    print("    ⚔️ MONARCHIE-ZEN BOT SYSTEM ⚔️")
    print("          by dev monarchie")
    print("     +243905061118 (WhatsApp Bot)")
    print("     https://whatsapp.com/channel/0029VbAYjn5KgsNpws3P633r")
    print("===================================\n")

def _main_():
    show_banner()

    if os.path.isdir(ubuntu):
        if os.geteuid() != 0:
            print("[x] Échec : vous devez être root.")
            sys.exit()

        if not os.path.isdir(ntfile[0]):
            print("[x] Échec : dossier '.module' manquant.")
            sys.exit()

        if not os.path.isdir(ntfile[1]):
            print("[x] Échec : dossier 'lib' manquant.")
            sys.exit()

        print(instal)

        # Modules Ubuntu
        execute_module_files('.module/files/', 'python3')

        if os.path.isdir('/adam'):
            os.system('rm -rf /usr/bin/lib')
            os.system(read_file('.module/pindahU.ms'))
            os.system(read_file('.module/PindahU.ms'))

        if not os.path.isdir('/usr/bin/lib'):
            os.system(read_file('.module/pindahU.ms'))
            os.system(read_file('.module/PindahU.ms'))

        print(read_file('.module/DU.la'))
        print(read_file('.module/Du'))
        os.system('python3 .JM.xn')

    elif os.path.isdir(termux):
        if not os.path.isdir(ntfile[0]) or not os.path.isdir(ntfile[1]):
            print("[x] Échec : dossier requis manquant dans Termux.")
            sys.exit()

        print(instal)

        # Modules Termux
        execute_module_files('.module/', 'python2')

        if os.path.isdir(termlb):
            os.system(read_file('.module/pacar.ms'))
            os.system(read_file('.module/pindahT.ms'))
            os.system(read_file('.module/PINDAHT.txt'))

        if not os.path.isdir(termlb):
            os.system(read_file('.module/pindahT.ms'))
            os.system(read_file('.module/PINDAHT.txt'))

        print(read_file('.module/DU.la'))
        print(read_file('.module/Du'))
        os.system('python2 .JM.xn && cd')

if __name__ == '__main__':
    _main_()