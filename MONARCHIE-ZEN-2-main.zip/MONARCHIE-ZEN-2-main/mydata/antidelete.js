const config = require('./config');

let deletedMessages = new Map();
let isAntiDeleteEnabled = false;

const deletedMessagesChatId = config.DELETED_MESSAGES_CHAT_ID || '554488138425@s.whatsapp.net';

const handleDeletedMessages = async (sock, message) => {
  if (!isAntiDeleteEnabled) return;

  if (!deletedMessages.has(message.id)) {
    deletedMessages.set(message.id, {
      from: message.from,
      content: message.body || '[Message inconnu]',
      timestamp: message.timestamp,
    });

    console.log(`[MONARCHIE-ZEN ⚔️] ⚠️ Message effacé détecté de ${message.from} ! Contenu capturé.`);

    await sendDeletedMessageToChat(sock, message.id);
  } else {
    console.log(`[MONARCHIE-ZEN ⚔️] Message déjà traité. Système stable.`);
  }
};

const sendDeletedMessageToChat = async (sock, messageId) => {
  const deletedMessage = deletedMessages.get(messageId);
  if (!deletedMessage) {
    console.error(`[MONARCHIE-ZEN ⚔️] ❌ Impossible de retrouver le message effacé.`);
    return;
  }

  try {
    await sock.sendMessage(deletedMessagesChatId, {
      text: `🛡️【ANTI-DÉLÉTION】🛡️\n\n` +
            `📡 Source : ${deletedMessage.from}\n` +
            `💬 Message : ${deletedMessage.content}\n` +
            `⏳ Horodatage : ${new Date(deletedMessage.timestamp * 1000).toLocaleString()}\n\n` +
            `⚔️ *Système MONARCHIE-ZEN activé.*`,
    });
  } catch (err) {
    console.error(`[MONARCHIE-ZEN ⚔️] Erreur lors de l’envoi du message anti-suppression :`, err);
  }
};

const onMessageRevoke = (sock, message) => {
  if (message && message.id) {
    handleDeletedMessages(sock, message);
  }
};

const enableAntiDelete = () => {
  isAntiDeleteEnabled = true;
  console.log(`[MONARCHIE-ZEN ⚔️] Système Anti-Suppression ACTIVÉ. Aucune ombre ne passera.`);
};

const disableAntiDelete = () => {
  isAntiDeleteEnabled = false;
  console.log(`[MONARCHIE-ZEN ⚔️] Système Anti-Suppression DÉSACTIVÉ. Le silence revient.`);
};

module.exports = {
  onMessageRevoke,
  enableAntiDelete,
  disableAntiDelete,
};