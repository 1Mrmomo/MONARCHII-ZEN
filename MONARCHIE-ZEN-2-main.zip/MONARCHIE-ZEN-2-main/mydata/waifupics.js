import axios from 'axios'; // Invocation d'une requête mystique vers le royaume des Waifus

// Fonction pour invoquer une image aléatoire de waifu depuis l'API waifu.pics
export const getWaifuImage = async () => {
  try {
    const response = await axios.get('https://api.waifu.pics/sfw/waifu');
    console.log('[MONARCHIE-ZEN ⚔️] Invocation réussie : Waifu trouvée.');
    return response.data.url; // Renvoie l’artefact sacré (URL de l’image)
  } catch (error) {
    console.error('[MONARCHIE-ZEN ⚔️] Erreur d’invocation : la quête a échoué.', error);
    return null; // L’échec de la quête renvoie le néant
  }
};